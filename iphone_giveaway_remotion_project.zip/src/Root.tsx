import React from "react";
import { Composition } from "remotion";
import { IphoneGiveaway } from "./Video";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="IphoneGiveaway"
    component={IphoneGiveaway}
    durationInFrames={450}
    fps={30}
    width={1080}
    height={1920}
  />
);