import React from "react";
import {
  AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig,
} from "remotion";

const C = {
  bg: "#05070D", blue: "#5BE7FF", violet: "#8A5CFF", white: "#FFFFFF",
  muted: "rgba(255,255,255,.72)",
};

const Phone: React.FC<{delay?: number; scale?: number; rotate?: number}> = ({
  delay = 0, scale = 1, rotate = 0,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame: frame-delay, fps, config: {damping: 13, stiffness: 90}});
  const float = Math.sin((frame-delay)/17)*9;
  return (
    <div style={{
      position: "absolute", width: 260, height: 520, borderRadius: 48,
      padding: 10, boxSizing: "border-box",
      background: "linear-gradient(135deg,#F7F7FA,#6F7785 48%,#171B25)",
      boxShadow: "0 35px 90px rgba(0,0,0,.65), 0 0 55px rgba(91,231,255,.22)",
      transform: `translateY(${(1-enter)*180 + float}px) scale(${scale*enter}) rotate(${rotate}deg)`,
      opacity: enter,
    }}>
      <div style={{width:"100%",height:"100%",borderRadius:39,background:"linear-gradient(155deg,#111827,#273B66 50%,#080B12)",position:"relative",overflow:"hidden",border:"2px solid #B8C1D1"}}>
        <div style={{position:"absolute",top:13,left: "50%",transform:"translateX(-50%)",width:82,height:22,borderRadius:20,background:"#05070D"}}/>
        <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at 70% 35%,rgba(91,231,255,.7),transparent 27%),radial-gradient(circle at 25% 75%,rgba(138,92,255,.7),transparent 32%)"}}/>
        <div style={{position:"absolute",top:60,left:20,display:"flex",gap:8}}>
          {[0,1,2].map(i=><div key={i} style={{width:48,height:48,borderRadius:16,background:"linear-gradient(135deg,#111,#48566A)",border:"3px solid #8792A4"}}/>)}
        </div>
        <div style={{position:"absolute",bottom:28,left:0,right:0,textAlign:"center",color:"rgba(255,255,255,.8)",fontSize:18,fontWeight:700,letterSpacing:3}}>iPHONE</div>
      </div>
    </div>
  );
};

const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  const shift = Math.sin(frame/45)*35;
  return <AbsoluteFill style={{background:C.bg,overflow:"hidden"}}>
    <div style={{position:"absolute",width:900,height:900,borderRadius:"50%",left:-300+shift,top:260,background:"radial-gradient(circle,rgba(0,160,255,.24),transparent 68%)"}}/>
    <div style={{position:"absolute",width:850,height:850,borderRadius:"50%",right:-360-shift,top:720,background:"radial-gradient(circle,rgba(130,65,255,.27),transparent 68%)"}}/>
    <div style={{position:"absolute",inset:0,opacity:.12,backgroundImage:"linear-gradient(rgba(255,255,255,.12) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.12) 1px,transparent 1px)",backgroundSize:"72px 72px"}}/>
  </AbsoluteFill>;
};

const Caption: React.FC<{text:string; from:number; to:number; size?:number; color?:string}> = ({text,from,to,size=66,color=C.white}) => {
  const f=useCurrentFrame();
  const opacity=interpolate(f,[from,from+10,to-8,to],[0,1,1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  const y=interpolate(f,[from,from+12],[35,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  return <div style={{position:"absolute",top:250,left:65,right:65,textAlign:"center",fontSize:size,fontWeight:900,lineHeight:1.08,letterSpacing:-2,color,opacity,transform:`translateY(${y}px)`,textShadow:"0 5px 28px rgba(0,0,0,.5)"}}>{text}</div>;
};

export const IphoneGiveaway: React.FC = () => {
  const frame=useCurrentFrame();
  const {fps}=useVideoConfig();
  const pulse=1+Math.sin(frame/7)*.035;
  const ctaIn=spring({frame:350,fps,config:{damping:12}});
  return <AbsoluteFill style={{fontFamily:"Arial, Helvetica, sans-serif",color:C.white}}>
    <Backdrop/>
    <div style={{position:"absolute",top:72,left:0,right:0,textAlign:"center",fontSize:23,fontWeight:800,letterSpacing:7,color:C.blue}}>GIVEAWAY • TELEGRAM</div>
    <Caption text="ХОЧЕШЬ НОВЫЙ iPHONE?" from={12} to={105} size={67}/>
    <div style={{position:"absolute",top:430,left:0,right:0,display:"flex",justifyContent:"center",alignItems:"center"}}>
      <Phone delay={20} scale={0.88} rotate={-9}/>
      <Phone delay={28} scale={1.04} rotate={4}/>
      <Phone delay={36} scale={0.84} rotate={13}/>
    </div>
    <Caption text="УЧАСТВУЙ В РОЗЫГРЫШЕ!" from={112} to={220} size={59} color={C.blue}/>
    <div style={{position:"absolute",top:420,left:110,right:110,textAlign:"center",fontSize:34,lineHeight:1.35,fontWeight:700,color:C.muted,opacity:interpolate(frame,[130,145,210,220],[0,1,1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}>
      Перейди в Telegram-бот<br/>и ознакомься с условиями участия
    </div>
    <div style={{position:"absolute",top:780,left:0,right:0,display:"flex",justifyContent:"center",opacity:interpolate(frame,[225,240,325,340],[0,1,1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}>
      <Phone delay={225} scale={1.2}/>
    </div>
    <Caption text="ТВОЙ ШАНС — В ОДНОМ КЛИКЕ" from={238} to={340} size={54}/>
    <div style={{position:"absolute",left:70,right:70,bottom:310,textAlign:"center",transform:`scale(${ctaIn*pulse})`,opacity:ctaIn}}>
      <div style={{fontSize:29,fontWeight:800,color:C.blue,letterSpacing:4,marginBottom:18}}>ПЕРЕХОДИ В БОТ</div>
      <div style={{borderRadius:24,padding:"26px 20px",background:"linear-gradient(100deg,#12B8E8,#765BFF)",fontSize:39,fontWeight:900,boxShadow:"0 15px 55px rgba(40,130,255,.35)"}}>t.me/appleefreegift_bot</div>
      <div style={{fontSize:24,color:C.muted,marginTop:22}}>Условия и подробности — в боте</div>
    </div>
    <div style={{position:"absolute",bottom:100,left:50,right:50,textAlign:"center",fontSize:18,color:"rgba(255,255,255,.48)"}}>
      Участвуйте только после ознакомления с правилами розыгрыша
    </div>
  </AbsoluteFill>;
};